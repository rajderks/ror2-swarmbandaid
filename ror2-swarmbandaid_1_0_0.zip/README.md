# Risk of Rain 2 - Swarm bandaid fix.

Tired of the Swarm Artifact breaking due to mountain shrine in combination with Beetle Queens? This mod removes the queens so swarm keeps working.

Install with your favorite mod manager or by extracting the `SwarmBandaid` directory in the zip file into the `BepinEx/plugins` directory.
